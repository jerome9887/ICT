    function startVoteFunction() {
        var change = document.getElementById("toggle");
        if (change.innerHTML == "Start Voting")
        {
            change.innerHTML = "End Voting" ;

        }
        else {
            change.innerHTML = "Start Voting";

                                        }
    }

     function startRegFunction() {
        var change = document.getElementById("toggle1");
        if (change.innerHTML == "Start Registration")
        {
            change.innerHTML = "End Registration" ;
        }
        else {
            change.innerHTML = "Start Registration";

                                        }
    }

    $('#generate').click(function()
    {   
        $("#password").toggle();
        $("#pin").toggle();       
    });
//* FOR COLOR AND Paragraph JS
    $('button').on("click",function(){  
      //$('button').not(this).removeClass();
      $(this).toggleClass('active');
      });

    $( '#toggle' ).click(function() {
      $( '#VoteOn-going' ).slideToggle();
    });

    $( '#toggle1' ).click(function() {
      $( '#RegOn-going' ).slideToggle();
    });
